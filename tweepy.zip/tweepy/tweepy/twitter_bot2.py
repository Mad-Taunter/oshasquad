import tweepy

print('this is my twitter bot')

CONSUMER_KEY = 'moiaTavopOh8No2CQbEVzZd1t'
CONSUMER_SECRET = 'FwkLUgMXWMeLiIJM2LievvadUGEXvbIbMO9EVC2yZipRZehcOg'
ACCESS_KEY = '797505694287233024-Ga78wyhALsedAzBFEGqVymwaHTE0ikB'
ACCESS_SECRET = 'fx5L2BbUDKc7o8foxvuolbzxA7ZtjWMeENORJCF6W862T'

auth = tweepy.AuthHandler(CONSUMER_KEY, CONSUMER_SECRET)
auth.set_access_token(ACCESS_KEY, ACCESS_SECRET)
api = tweepy.API(auth)

