import tweepy
from time import sleep

#constants
FILENAME="botscript.txt"

consumer_token = 'moiaTavopOh8No2CQbEVzZd1t'
consumer_secret = 'FwkLUgMXWMeLiIJM2LievvadUGEXvbIbMO9EVC2yZipRZehcOg'
access_token = '797505694287233024-Ga78wyhALsedAzBFEGqVymwaHTE0ikB'
access_secret = 'fx5L2BbUDKc7o8foxvuolbzxA7ZtjWMeENORJCF6W862T'

#Twitter Info- changes based on user that will be tweeting
auth = tweepy.OAuthHandler(consumer_token, consumer_secret)#THIS IS WHERE YOUR TWITTER API CODE GOES
auth.set_access_token(access_token, access_secret)#THIS IS WHERE YOUR TWITTER API CODE GOES
api = tweepy.API(auth)
TWEET="Testing"

def send_a_tweet(TWEET):  #This function sends a single tweet
    try:
        api.update_status(TWEET)
    except tweepy.TweepError as e: #Used for twitter errors. Prints them out.
        print(e.reason)
     
def tweet_a_file(botscript): #This tweets out a file, one line at a time
    my_file=open('botscript.txt','r') #read all lines from the file. Saves in all_the_tweets
    all_the_tweets=my_file.readlines()
    my_file.close()
    for tweet in all_the_tweets:
        tweet=tweet.replace("\n","")
        try:
            api.update_status(tweet) #the code that tweets
            print(tweet) #for us to see what we are tweeting
            print("*********************************")#so we can see a break between tweets
            sleep(1500) #how long to break between tweets, in seconds
        except tweepy.TweepError as e: #Used for twitter errors. Prints them out.
            print(e.reason)

tweet_a_file(FILENAME)
