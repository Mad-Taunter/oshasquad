# keys_format.py shares the same format as keys.py.
# This file is not meant to be used in the main script.
# Instead, copy this file into keys.py and put your own
# keys there.
CONSUMER_KEY = 'moiaTavopOh8No2CQbEVzZd1t'
CONSUMER_SECRET = 'FwkLUgMXWMeLiIJM2LievvadUGEXvbIbMO9EVC2yZipRZehcOg'
ACCESS_KEY = '797505694287233024-Ga78wyhALsedAzBFEGqVymwaHTE0ikB'
ACCESS_SECRET = 'fx5L2BbUDKc7o8foxvuolbzxA7ZtjWMeENORJCF6W862T'
